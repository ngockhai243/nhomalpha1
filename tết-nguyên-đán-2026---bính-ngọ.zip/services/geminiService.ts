
import { GoogleGenAI, Type } from "@google/genai";
import { WishRequest } from "../types";

export const generateTetWishes = async (request: WishRequest): Promise<string[]> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  
  const prompt = `Bạn là một AI chuyên viết lời chúc Tết Việt Nam. Hãy viết 3 câu chúc Tết Nguyên Đán 2026 (năm Bính Ngọ) khác nhau hoàn toàn.
  - Đối tượng: ${request.target}
  - Giọng điệu: ${request.tone}
  - Độ dài yêu cầu: ${request.length}
  - Chủ đề bổ sung: ${request.topic || 'Không có'}
  
  Yêu cầu ngôn từ:
  - Sử dụng tiếng Việt thuần túy, tự nhiên, không máy móc.
  - Phù hợp không khí Tết 2026 (Bính Ngọ), có thể nhắc đến hình ảnh con ngựa "Mã đáo thành công".
  - Có thể dùng để gửi qua Zalo, Facebook hoặc ghi thiệp.
  - Không lặp lại ý tứ giữa 3 câu.
  
  Trả về kết quả dưới dạng mảng JSON chứa 3 chuỗi ký tự.`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        temperature: 0.9,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: { type: Type.STRING }
        }
      }
    });

    const text = response.text;
    if (text) {
      return JSON.parse(text);
    }
    return ["Chúc mừng năm mới 2026!", "Vạn sự như ý!", "An khang thịnh vượng!"];
  } catch (error) {
    console.error("Error generating wishes:", error);
    return [
      "Chúc mừng năm mới Bính Ngọ 2026! Chúc bạn mã đáo thành công, vạn sự như ý.",
      "Cung chúc tân xuân! Chúc gia đình bạn một năm mới bình an, hạnh phúc và tài lộc đầy nhà.",
      "Năm mới Bính Ngọ, chúc bạn luôn tràn đầy năng lượng như chú tuấn mã, gặt hái nhiều thành công rực rỡ!"
    ];
  }
};
