
import React, { useEffect, useState } from 'react';

const FallingDecor: React.FC = () => {
  const [elements, setElements] = useState<{ id: number; left: string; delay: string; duration: string; type: string; size: number }[]>([]);

  useEffect(() => {
    const types = ['🌸', '🌼', '🧧'];
    const newElements = Array.from({ length: 30 }).map((_, i) => ({
      id: i,
      left: `${Math.random() * 100}%`,
      delay: `${Math.random() * 5}s`,
      duration: `${5 + Math.random() * 5}s`,
      type: types[Math.floor(Math.random() * types.length)],
      size: 15 + Math.random() * 20
    }));
    setElements(newElements);
  }, []);

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden" style={{ zIndex: 10 }}>
      {elements.map((el) => (
        <div
          key={el.id}
          className="petal"
          style={{
            left: el.left,
            animationDelay: el.delay,
            animationDuration: el.duration,
            fontSize: `${el.size}px`
          }}
        >
          {el.type}
        </div>
      ))}
    </div>
  );
};

export default FallingDecor;
