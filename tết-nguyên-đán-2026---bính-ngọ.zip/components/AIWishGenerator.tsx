
import React, { useState } from 'react';
import { generateTetWishes } from '../services/geminiService';
import { TARGETS, TONES, LENGTHS } from '../constants';
import { WishRequest } from '../types';

const AIWishGenerator: React.FC = () => {
  const [loading, setLoading] = useState(false);
  const [wishes, setWishes] = useState<string[]>([]);
  const [formData, setFormData] = useState<WishRequest>({
    target: TARGETS[1].label, // Cha mẹ
    tone: TONES[3].label,   // Tình cảm
    topic: '',
    length: LENGTHS[1].label // Vừa
  });

  const handleGenerate = async () => {
    setLoading(true);
    setWishes([]);
    try {
      const results = await generateTetWishes(formData);
      setWishes(results);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    alert("Đã sao chép câu chúc!");
  };

  return (
    <div className="bg-white rounded-3xl shadow-xl p-6 md:p-8 border-t-8 border-yellow-500">
      <h3 className="text-3xl font-traditional text-red-800 mb-6 flex items-center gap-3">
        <span className="bg-yellow-100 p-2 rounded-full">✍️</span> AI Sáng Tác Câu Chúc
      </h3>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div>
          <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Đối tượng</label>
          <select 
            className="w-full px-4 py-3 bg-gray-50 border-2 border-transparent focus:border-yellow-500 rounded-2xl outline-none transition-all font-medium"
            value={formData.target}
            onChange={(e) => setFormData({...formData, target: e.target.value})}
          >
            {TARGETS.map(t => <option key={t.value} value={t.label}>{t.label}</option>)}
          </select>
        </div>
        <div>
          <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Giọng điệu</label>
          <select 
            className="w-full px-4 py-3 bg-gray-50 border-2 border-transparent focus:border-yellow-500 rounded-2xl outline-none transition-all font-medium"
            value={formData.tone}
            onChange={(e) => setFormData({...formData, tone: e.target.value})}
          >
            {TONES.map(t => <option key={t.value} value={t.label}>{t.label}</option>)}
          </select>
        </div>
        <div>
          <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Độ dài</label>
          <select 
            className="w-full px-4 py-3 bg-gray-50 border-2 border-transparent focus:border-yellow-500 rounded-2xl outline-none transition-all font-medium"
            value={formData.length}
            onChange={(e) => setFormData({...formData, length: e.target.value})}
          >
            {LENGTHS.map(l => <option key={l.value} value={l.label}>{l.label}</option>)}
          </select>
        </div>
      </div>

      <div className="mb-8">
        <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Chủ đề/Ý muốn riêng (tùy chọn)</label>
        <input 
          type="text"
          placeholder="VD: Chúc sức khỏe, thi cử, mua nhà..."
          className="w-full px-4 py-3 bg-gray-50 border-2 border-transparent focus:border-yellow-500 rounded-2xl outline-none transition-all font-medium"
          value={formData.topic}
          onChange={(e) => setFormData({...formData, topic: e.target.value})}
        />
      </div>

      <button
        onClick={handleGenerate}
        disabled={loading}
        className={`w-full py-4 rounded-2xl font-bold text-white text-lg shadow-lg transition-all transform active:scale-95 flex items-center justify-center gap-3 ${
          loading ? 'bg-gray-400 cursor-not-allowed' : 'bg-red-600 hover:bg-red-700 shadow-red-200'
        }`}
      >
        {loading ? (
          <>
            <div className="w-6 h-6 border-3 border-white border-t-transparent rounded-full animate-spin"></div>
            Đang "múa bút"...
          </>
        ) : (
          <><span>🧧</span> Tạo 3 Lời Chúc Ý Nghĩa</>
        )}
      </button>

      {wishes.length > 0 && (
        <div className="mt-10 space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
          <p className="text-sm font-bold text-gray-500 text-center uppercase tracking-widest">Gợi ý từ AI cho bạn:</p>
          {wishes.map((w, idx) => (
            <div key={idx} className="group relative p-6 bg-gradient-to-r from-red-50 to-white rounded-2xl border-2 border-red-100 hover:border-red-300 transition-all">
              <p className="text-gray-800 leading-relaxed pr-10 text-lg italic">"{w}"</p>
              <button 
                onClick={() => copyToClipboard(w)}
                className="absolute top-4 right-4 p-2 bg-white text-red-500 hover:bg-red-500 hover:text-white rounded-xl shadow-sm transition-all border border-red-100"
                title="Sao chép"
              >
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><rect width="14" height="14" x="8" y="8" rx="2" ry="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/></svg>
              </button>
              <div className="mt-4 flex justify-end">
                 <span className="text-[10px] font-bold text-red-300 uppercase tracking-tighter">Phương án {idx + 1}</span>
              </div>
            </div>
          ))}
        </div>
      )}
      
      <div className="mt-8 p-4 bg-orange-50 rounded-2xl border border-orange-100 text-xs text-orange-700 leading-relaxed">
        <strong>Mách nhỏ:</strong> Bạn có thể chọn giọng điệu "Hài hước" để gửi cho bạn bè, hoặc "Trang trọng" khi gửi cho Sếp và Khách hàng để ghi điểm tuyệt đối nhé!
      </div>
    </div>
  );
};

export default AIWishGenerator;
