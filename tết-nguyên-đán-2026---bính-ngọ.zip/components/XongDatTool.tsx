
import React, { useState } from 'react';
import { Zodiac } from '../types';
import { getCanChi, getMenh, getTopGuests } from '../utils/horoscopeUtils';

const XongDatTool: React.FC = () => {
  const [birthYear, setBirthYear] = useState<string>('');
  const [gender, setGender] = useState<'Nam' | 'Nữ'>('Nam');
  const [showResult, setShowResult] = useState(false);

  const homeownerCanChi = birthYear ? getCanChi(parseInt(birthYear)) : null;
  const homeownerMenh = birthYear ? getMenh(parseInt(birthYear)) : '';
  const topGuests = birthYear ? getTopGuests(parseInt(birthYear)) : [];

  const handleCheck = () => {
    const year = parseInt(birthYear);
    if (isNaN(year) || year < 1920 || year > 2026) {
      alert('Vui lòng nhập năm sinh gia chủ từ 1920 đến 2026.');
      return;
    }
    setShowResult(true);
  };

  return (
    <div className="bg-white rounded-3xl shadow-2xl p-6 md:p-8 border-t-8 border-teal-600">
      <h3 className="text-3xl font-traditional text-red-800 mb-6 flex items-center gap-3">
        <span className="bg-teal-100 p-2 rounded-full">🐎</span> Xem Tuổi Xông Đất 2026
      </h3>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
        <div>
          <label className="block text-sm font-semibold text-gray-600 mb-2 uppercase tracking-wider">Năm sinh gia chủ</label>
          <input
            type="number"
            value={birthYear}
            onChange={(e) => {
              setBirthYear(e.target.value);
              setShowResult(false);
            }}
            placeholder="VD: 1985"
            className="w-full px-4 py-3 border-2 border-gray-100 rounded-2xl focus:border-teal-500 focus:ring-0 transition-all outline-none bg-gray-50 font-bold text-lg"
          />
        </div>
        <div>
          <label className="block text-sm font-semibold text-gray-600 mb-2 uppercase tracking-wider">Giới tính</label>
          <div className="flex p-1 bg-gray-100 rounded-2xl">
            <button
              onClick={() => { setGender('Nam'); setShowResult(false); }}
              className={`flex-1 py-2 rounded-xl font-bold transition-all ${gender === 'Nam' ? 'bg-white text-teal-600 shadow-sm' : 'text-gray-400'}`}
            >
              Nam
            </button>
            <button
              onClick={() => { setGender('Nữ'); setShowResult(false); }}
              className={`flex-1 py-2 rounded-xl font-bold transition-all ${gender === 'Nữ' ? 'bg-white text-teal-600 shadow-sm' : 'text-gray-400'}`}
            >
              Nữ
            </button>
          </div>
        </div>
      </div>

      <button
        onClick={handleCheck}
        className="w-full bg-teal-600 hover:bg-teal-700 text-white font-bold py-4 rounded-2xl shadow-lg hover:shadow-teal-200 transition-all mb-8 flex items-center justify-center gap-2 text-lg"
      >
        <span>🔍</span> Tìm Người Hợp Tuổi
      </button>

      {showResult && homeownerCanChi && (
        <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
          {/* Homeowner Info */}
          <div className="bg-teal-50 rounded-2xl p-5 border border-teal-100 flex items-center gap-4">
            <div className="text-4xl">🏠</div>
            <div>
              <p className="text-teal-800 font-bold text-lg">Gia chủ: {homeownerCanChi.can} {homeownerCanChi.chi}</p>
              <p className="text-teal-600">Mệnh: {homeownerMenh} — Tuổi: {2026 - parseInt(birthYear)}</p>
            </div>
          </div>

          <h4 className="text-xl font-bold text-gray-800 border-l-4 border-teal-500 pl-3">3 Tuổi Đẹp Nhất Để Xông Đất:</h4>

          <div className="grid grid-cols-1 gap-4">
            {topGuests.map((guest, idx) => (
              <div key={idx} className="bg-white border-2 border-gray-50 hover:border-teal-200 rounded-2xl p-5 shadow-sm hover:shadow-md transition-all flex items-center gap-5">
                <div className="w-14 h-14 bg-gradient-to-br from-teal-400 to-teal-600 rounded-full flex items-center justify-center text-2xl text-white font-bold shadow-inner">
                  {idx + 1}
                </div>
                <div className="flex-1">
                  <p className="text-xl font-bold text-gray-800">{guest.name}</p>
                  <p className="text-sm text-gray-500">
                    <span className="text-teal-600 font-medium italic">Giải thích:</span> Tuổi này tương sinh về bản mệnh và nằm trong vòng Tam Hợp/Lục Hợp với gia chủ và năm 2026.
                  </p>
                </div>
                <div className="text-right">
                  <span className="bg-green-100 text-green-700 text-xs font-bold px-2 py-1 rounded-full uppercase tracking-tighter">Rất Hợp</span>
                </div>
              </div>
            ))}
          </div>

          <div className="bg-red-50 p-5 rounded-2xl border border-red-100">
            <h5 className="font-bold text-red-800 flex items-center gap-2 mb-2">
              <span>🚫</span> Tuổi cần tránh (Xung khắc):
            </h5>
            <p className="text-sm text-red-600 leading-relaxed">
              Trong năm Bính Ngọ, gia chủ nên hạn chế mời những người tuổi <strong>Tý, Mão, Dậu</strong> đến xông đất đầu năm để tránh những xung đột về năng lượng, giúp gia đạo bình an hơn.
            </p>
          </div>
          
          <p className="text-center text-gray-400 text-xs italic">
            * Thông tin mang tính chất tham khảo dân gian để tăng thêm niềm vui ngày Tết.
          </p>
        </div>
      )}
    </div>
  );
};

export default XongDatTool;
