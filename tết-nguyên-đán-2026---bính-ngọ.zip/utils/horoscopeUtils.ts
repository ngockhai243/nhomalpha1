
import { Zodiac } from '../types';

export const CAN_LIST = ["Giáp", "Ất", "Bính", "Đinh", "Mậu", "Kỷ", "Canh", "Tân", "Nhâm", "Quý"];
export const CHI_LIST = ["Tý", "Sửu", "Dần", "Mão", "Thìn", "Tỵ", "Ngọ", "Mùi", "Thân", "Dậu", "Tuất", "Hợi"];

export const MENH_LIST = [
  "Kim", "Thủy", "Hỏa", "Thổ", "Mộc"
];

// Simple mapping for demonstration of compatibility
// In real apps, this would be a complex lookup table
export const getCanChi = (year: number) => {
  if (year < 1900) return { can: "", chi: "" as Zodiac };
  const canIndex = (year - 4) % 10;
  const chiIndex = (year - 4) % 12;
  return {
    can: CAN_LIST[canIndex],
    chi: CHI_LIST[chiIndex] as Zodiac
  };
};

export const getMenh = (year: number) => {
  // Simplified Menh calculation logic
  const canIndices: Record<string, number> = { "Giáp": 1, "Ất": 1, "Bính": 2, "Đinh": 2, "Mậu": 3, "Kỷ": 3, "Canh": 4, "Tân": 4, "Nhâm": 5, "Quý": 5 };
  const chiIndices: Record<string, number> = { "Tý": 0, "Sửu": 0, "Ngọ": 0, "Mùi": 0, "Dần": 1, "Mão": 1, "Thân": 1, "Dậu": 1, "Thìn": 2, "Tỵ": 2, "Tuất": 2, "Hợi": 2 };
  
  const { can, chi } = getCanChi(year);
  let val = canIndices[can] + chiIndices[chi];
  if (val > 5) val -= 5;
  
  const results = ["", "Kim", "Thủy", "Hỏa", "Thổ", "Mộc"];
  return results[val] || "Thủy";
};

export const getTopGuests = (ownerYear: number) => {
  const { chi: ownerChi } = getCanChi(ownerYear);
  const ownerMenh = getMenh(ownerYear);

  // 2026 is Bính Ngọ (Thủy)
  // General good zodiacs for Ngọ year: Dần, Tuất, Mùi
  const candidates = [
    { year: 1962, zodiac: Zodiac.Dan, name: "Nhâm Dần (1962)" },
    { year: 1970, zodiac: Zodiac.Tuat, name: "Canh Tuất (1970)" },
    { year: 1979, zodiac: Zodiac.Mui, name: "Kỷ Mùi (1979)" },
    { year: 1982, zodiac: Zodiac.Tuat, name: "Nhâm Tuất (1982)" },
    { year: 1986, zodiac: Zodiac.Dan, name: "Bính Dần (1986)" },
    { year: 1991, zodiac: Zodiac.Mui, name: "Tân Mùi (1991)" },
    { year: 1994, zodiac: Zodiac.Tuat, name: "Giáp Tuất (1994)" },
    { year: 1998, zodiac: Zodiac.Dan, name: "Mậu Dần (1998)" },
    { year: 2003, zodiac: Zodiac.Mui, name: "Quý Mùi (2003)" }
  ];

  // Logic: Filter candidates that don't clash with owner's Chi and Menh
  // Homeowner Chi shouldn't be in Tứ Hành Xung with Guest Chi
  const clashes: Record<string, string[]> = {
    "Tý": ["Ngọ", "Mão", "Dậu"],
    "Ngọ": ["Tý", "Mão", "Dậu"],
    "Sửu": ["Mùi", "Thìn", "Tuất"],
    "Mùi": ["Sửu", "Thìn", "Tuất"],
    "Dần": ["Thân", "Tỵ", "Hợi"],
    "Thân": ["Dần", "Tỵ", "Hợi"],
    "Mão": ["Dậu", "Tý", "Ngọ"],
    "Dậu": ["Mão", "Tý", "Ngọ"],
    "Thìn": ["Tuất", "Sửu", "Mùi"],
    "Tuất": ["Thìn", "Sửu", "Mùi"],
    "Tỵ": ["Hợi", "Dần", "Thân"],
    "Hợi": ["Tỵ", "Dần", "Thân"],
  };

  const scored = candidates.map(c => {
    let score = 50;
    const guestMenh = getMenh(c.year);
    
    // Check Chi compatibility with Owner
    if (clashes[ownerChi]?.includes(c.zodiac)) score -= 40;
    if (["Dần", "Tuất", "Mão"].includes(ownerChi) && c.zodiac === Zodiac.Mui) score += 20; // Example compatibility

    // Check Menh compatibility with Owner
    // Simplified: Thủy sinh Mộc, Mộc sinh Hỏa, Hỏa sinh Thổ, Thổ sinh Kim, Kim sinh Thủy
    const relations: Record<string, string> = { "Kim": "Thủy", "Thủy": "Mộc", "Mộc": "Hỏa", "Hỏa": "Thổ", "Thổ": "Kim" };
    if (relations[guestMenh] === ownerMenh) score += 15; // Guest supports Owner
    if (relations[ownerMenh] === guestMenh) score += 10; // Owner supports Guest
    if (guestMenh === ownerMenh) score += 5;

    return { ...c, score };
  });

  return scored.sort((a, b) => b.score - a.score).slice(0, 3);
};
